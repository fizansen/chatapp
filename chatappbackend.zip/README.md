**chit-chat-backend**

**Backend for that chit-chat-client follow this link:**

https://github.com/faizaniqbalLC/chit-chat-client

## Available Scripts

In the project directory, you can run:
### `npm install`

For Installing all dependencies in package.json.\

### `npm start`

Runs the backend according to user defined port.\
Open [http://localhost:PORT](http://localhost:PORT) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)
